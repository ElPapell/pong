keycode = {
  KEYDOWN : 40,
  KEYUP : 38,
  player2Up : 90,
  player2Down : 83
}